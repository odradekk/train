using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using Train.Content;
using Train.Domain.Rails;
using Train.Domain.Voxels;
using Train.Tests;

// Acceptance-only driver: references the unchanged, already-built test assembly.
// Reflection is limited to reusing its existing internal fixture factory.
if (!OperatingSystem.IsWindows() || RuntimeInformation.ProcessArchitecture != Architecture.X64)
    throw new Exception("Windows x64 required");
Console.WriteLine($"RUNTIME {RuntimeInformation.FrameworkDescription} {RuntimeInformation.RuntimeIdentifier} {RuntimeEnvironment.GetRuntimeDirectory()}");
var assembly = typeof(TrainPersistenceTests).Assembly;
Console.WriteLine($"ASSEMBLY {assembly.Location} SHA256={Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(assembly.Location)))} MVID={assembly.ManifestModule.ModuleVersionId}");
Console.WriteLine($"GENERATOR {VoxelWorldIdentity.Slice4GeneratorVersion}");
var rows = new List<string> { "scenario,branch,step,sha256" };
string? contentIdentity = null;

using (var live = Harness.Parked())
using (var repeat = Harness.Parked())
{
    Content(live); Content(repeat);
    Require(live.Session.StartTrain(RailHeading.AlongAlignment, 0).Succeeded, "start live");
    Require(repeat.Session.StartTrain(RailHeading.AlongAlignment, 0).Succeeded, "start repeat");
    Harness? resumed = null;
    try
    {
        for (ulong step = 0; step <= 1800; step += 300)
        {
            Advance(live, step); Advance(repeat, step);
            Equal("running", "repeat", live, repeat);
            if (step == 900) { resumed = Harness.Resume(live); Content(resumed); }
            if (resumed != null) { Advance(resumed, step); Equal("running", "resume900", live, resumed); }
        }
        Require(live.Session.StopTrain().Succeeded && repeat.Session.StopTrain().Succeeded && resumed!.Session.StopTrain().Succeeded, "stop");
        Equal("stopped1800", "repeat", live, repeat);
        Equal("stopped1800", "resume900", live, resumed!);
    }
    finally { resumed?.Dispose(); }
}

using (var live = Harness.Parked())
{
    Content(live);
    Require(live.Session.StartTrain(RailHeading.AlongAlignment, 0).Succeeded, "coast start");
    Advance(live, 300);
    var train = live.Session.QueryTrainAssemblies().Single();
    Require(live.Session.Damage(train.ActiveLocomotiveId!.Value, train.Connections[0].FromCell, 100).Succeeded, "break coupler");
    Advance(live, 330);
    Require(live.Session.QueryTrainAssemblies().Single(x => x.ActiveLocomotiveId is null).Speed > 0, "saving while coasting");
    using var resumed = Harness.Resume(live); Content(resumed);
    foreach (ulong step in new ulong[] { 330, 540, 600, 900, 1200, 1500, 1800 })
    {
        Advance(live, step); Advance(resumed, step);
        Equal("coast", "resume330", live, resumed);
        if (step >= 540) Require(Math.Abs(resumed.Session.QueryTrainAssemblies().Single(x => x.ActiveLocomotiveId is null).Speed) <= 1e-8, "coast stops");
    }
}

using (var live = Harness.Parked())
{
    Content(live);
    Require(live.Session.StartTrain(RailHeading.AlongAlignment, 0).Succeeded, "gap start");
    Advance(live, 300);
    Require(live.Session.Damage(StraightRailFixture.FirstSegmentDamageCell, 100).Succeeded, "damage forward rail");
    while (live.Session.QueryTrainAssemblies().Single().Speed > 0 && live.Session.SimulationStep < 900)
        Require(live.Session.AdvanceSimulation(1).Succeeded, "advance to gap stop");
    var stopped = live.Session.QueryTrainAssemblies().Single();
    Require(stopped.Speed == 0 && stopped.HaltReason == TrainHaltReason.ForwardGap, "gap halt before saving");
    Console.WriteLine($"GAP_SAVE step={live.Session.SimulationStep} speed={stopped.Speed} reason={stopped.HaltReason}");
    using var resumed = Harness.Resume(live); Content(resumed);
    Equal("gap", "resumeStop", live, resumed);
    for (ulong step = (live.Session.SimulationStep / 300 + 1) * 300; step <= 1800; step += 300)
    {
        Advance(live, step); Advance(resumed, step);
        Equal("gap", "resumeStop", live, resumed);
    }
}
File.WriteAllLines(args[0], rows);
Console.WriteLine($"PASS rows={rows.Count - 1} content={contentIdentity}");

void Content(Harness harness)
{
    var r = (ContentReloader)harness.Get("Reloader");
    var lines = r.Catalog.Current!.Entries.Select(x => $"voxel {x.Key.Value} {x.Value.SemanticRevision}")
        .Concat(r.Composites.Current!.Archetypes.Select(x => $"archetype {x.Key.Value} {x.Value.SemanticRevision}"))
        .Concat(r.Composites.Current!.Composites.Select(x => $"composite {x.Key.Value} {x.Value.SemanticRevision}"))
        .OrderBy(x => x, StringComparer.Ordinal).ToArray();
    var identity = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(string.Join("\n", lines))));
    if (contentIdentity is null)
    {
        contentIdentity = identity;
        File.WriteAllLines(Path.ChangeExtension(args[0], ".content.txt"), lines);
    }
    Require(identity == contentIdentity, "same effective semantic content");
}
void Equal(string scenario, string branch, Harness live, Harness candidate)
{
    var a = WorldSaveAuthority.Fingerprint(live.Session);
    var b = WorldSaveAuthority.Fingerprint(candidate.Session);
    var liveState = live.Session.CaptureTrainAuthority();
    var candidateState = candidate.Session.CaptureTrainAuthority();
    // AC6 excludes derived graphs. The diagnostic snapshot also carries a cache
    // freshness flag, which changes on load; normalize only that non-authority bit.
    // The canonical authority hashes above are compared without any normalization.
    var authorityState = liveState with { Rails = liveState.Rails with { DerivedGraphCurrent = candidateState.Rails.DerivedGraphCurrent } };
    Require(a == b && authorityState.Equals(candidateState), $"authority {scenario}/{branch} at {live.Session.SimulationStep}");
    rows.Add($"{scenario},live,{live.Session.SimulationStep},{a}");
    rows.Add($"{scenario},{branch},{candidate.Session.SimulationStep},{b}");
    Console.WriteLine($"MATCH {scenario}/{branch} step={live.Session.SimulationStep} sha256={a}");
}
static void Advance(Harness h, ulong step)
{
    Require(step >= h.Session.SimulationStep, "monotonic step");
    if (step > h.Session.SimulationStep) Require(h.Session.AdvanceSimulation(step - h.Session.SimulationStep).Succeeded, "advance");
}
static void Require(bool condition, string message) { if (!condition) throw new Exception(message); }

sealed class Harness(object inner) : IDisposable
{
    static readonly Type Type = typeof(TrainPersistenceTests).Assembly.GetType("Train.Tests.StaticTrainHarness")!;
    public object Get(string name) => Type.GetProperty(name)!.GetValue(inner)!;
    public VoxelDevelopmentSession Session => (VoxelDevelopmentSession)Get("Session");
    public static Harness Parked() => new(typeof(TrainPersistenceTests).GetMethod("Parked", BindingFlags.NonPublic | BindingFlags.Static)!.Invoke(null, null)!);
    public static Harness Resume(Harness live)
    {
        var saved = live.Session.Save("Windows AC6 verification");
        if (saved.Status != WorldSaveStatus.Saved) throw new Exception("save failed");
        var result = new Harness(Type.GetMethod("Create")!.Invoke(null, [live.Get("UserData"), live.Get("Source")])!);
        if (result.Session.Load(saved.SaveId!.Value).Status != WorldSaveStatus.Loaded) throw new Exception("load failed");
        return result;
    }
    public void Dispose() => ((IDisposable)inner).Dispose();
}
