# Issue #74 Windows x64 authority

- SHA recorded at execution: fac541484ab4bdd3b94dfb09248896e3d650200b
- OS: Microsoft Windows 10.0.26200
- dotnet SDK: 10.0.111
- Microsoft.NETCore.App 10.x runtimes present:
  - Microsoft.NETCore.App 10.0.11 [D:\Code\train-issue74-environment\tools\dotnet\shared\Microsoft.NETCore.App]
- This process FrameworkDescription: .NET 10.0.11
- Testhost runtime: not proven by listing 10.x or taking the last line. On Windows, record the testhost `FrameworkDescription` from the passing `dotnet test` process.
- GODOT: D:\Godot_v4.7.2-stable_mono_win64\Godot_v4.7.2-stable_mono_win64_console.exe
- Godot version: 4.7.2.stable.mono.official.ed1daf0bf
- Evidence kind: source checkout `dotnet test` / optional Godot smoke. Not the exported `train.exe`.
- Content identity from this checkout: built-in published `core` voxels/composites; world generator `slice-4-straight-rail-v1` (from `VoxelWorldIdentity.Slice4GeneratorVersion`).
- This script does not gate on a hard-coded SHA or a single 10.0.x patch. Record the runtime and generator actually used on the Windows host.

- PASS `dotnet test --filter FullyQualifiedName~Start_at_zero_save_at_900_new_session_load_matches_uninterrupted_checkpoints`
- PASS `dotnet test --filter FullyQualifiedName~Formal_save_at_330_resumes_the_same_authority_and_keeps_zero_after_coast_stop`
- PASS `dotnet test --filter FullyQualifiedName~Formal_files_restore_halts_and_reject_missing_geometry_without_replacing_the_session`
- PASS `scripts/run-godot-voxel-smoke.ps1 -Slice 4`
- Testhost FrameworkDescription must be copied from the passing `dotnet test` testhost (not from `--list-runtimes` last line). This pwsh process was .NET 10.0.11.
- Result: Windows x64 source-build authority checks passed for SHA fac541484ab4bdd3b94dfb09248896e3d650200b.
